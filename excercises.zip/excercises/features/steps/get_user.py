from behave import *

import requests, json
from pprint import pprint

def http_call():
    url = "https://reqres.in/api/users/2"

    payload={}
    headers = {}

    response = requests.request("GET", url, headers=headers, data=payload)
    if response.status_code == 200:
        Jsonresponse=response.json()
        return Jsonresponse
    else:
        return None


@given('users data')
def step_impl(context):
    pass

@when('retrieve users list')
def step_impl(context):
    data=http_call()
    if data:
        assert True
    else:
        assert context.failed is True

@then('users list should be retrieved from API')
def step_impl(context):
    assert context.failed is False
from behave import *

import requests, json
from pprint import pprint

def http_call():
    url = "https://reqres.in/api/users/2"
    payload = json.dumps({
    "name": "morpheus",
    "job": "leader"
    })
    headers = {
    'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=payload)
    if response.status_code == 201:
        Jsonresponse=response.json()
        return Jsonresponse
    else:
        return None


@given('user data')
def step_impl(context):
    pass

@when('Adding data using API')
def step_impl(context):
    data=http_call()
    if data:
        assert True
    else:
        assert context.failed is True

@then('user details gets added to the DB')
def step_impl(context):
    assert context.failed is False
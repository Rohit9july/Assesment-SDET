import csv
import os
from pprint import pprint

#Reading the input files
file1=os.path.join(os.getcwd(),'app/in/InstrumentDetails.csv')
file2=os.path.join(os.getcwd(),'app/in/PositionDetails.csv')
with open(file1, newline='') as csvfile:
    instruments = list(csv.DictReader(csvfile))

with open(file2, newline='') as csvfile:
    positions = list(csv.DictReader(csvfile))

#Merging files into one csv file
fields = ['ID', 'PositionID', 'ISIN', 'Quantity','Total Price']
rows=[]
for row in instruments:
    isin=row['ISIN']
    for entry in positions:
        if entry['InstrumentID']==isin:
            total_price=int(row['Unit Price'])*int(entry['Quantity'])
            data=[row['ID'],entry['ID'],isin,entry['Quantity'],total_price]
            rows.append(data)

#Writing to out file
out_file=os.path.join(os.getcwd(),'app/out/PositionReport.csv')
with open(out_file, 'w') as csvfile: 
    csvwriter = csv.writer(csvfile) 
    csvwriter.writerow(fields) 
    csvwriter.writerows(rows)

import pandas as pd
 
# reading the CSV file
idF = pd.read_csv('./app/in/InstrumentDetails.csv')
pidF = pd.read_csv('./app/in/PositionDetails.csv')
pRF = pd.read_csv('./app/out/PositionReport.csv')
#Test data for local testing
# idFl = [('IID1', 'Name1', 'ABCD', 1), ('IID2', 'Name2', 'EFGH', 20)]
# pidFl = [('PID1', 'IID1', 50), ('PID2', 'IID2', 200)]
# pRFl = [('IID1', 'PID1', 'ABCD', 50, 50), ('IID2', 'PID2', 'ABCD', 50, 4000)]
#
# idF = pd.DataFrame(idFl,
#                   columns=['IID', 'Name', 'ISIN', 'Unit Price'])
# pidF = pd.DataFrame(pidFl,
#                   columns=['PID', 'IID', 'Quantity'])
# pRF = pd.DataFrame(pRFl,
#                   columns=['IID', 'PID', 'ISIN', 'Quantity', 'Total Price'])
# pRF = pRF.reset_index()
#print(pRF)

#Comment above line for reading from csv
# pRF.set_index('PID')
for index, pRRow in pRF.iterrows():
    # print(pRRow['IID'])
    idetail = idF.loc[idF['IID'] == pRRow['IID']]
    pdetail = pidF.loc[pidF['PID'] == pRRow['PID']]
    if idetail['IID'].values[0] == pdetail['IID'].values[0] \
            and idetail['ISIN'].values[0] == pRRow['ISIN']\
            and pdetail['Quantity'].values[0] == pRRow['Quantity']\
            and idetail['Unit Price'].values[0] * pdetail['Quantity'].values[0] == pRRow['Total Price']:
        print('Test passed for Instrument detail ID' + idetail['IID'].values[0])
    else:
        print('Test failed for Instrument detail ID' + idetail['IID'].values[0])
